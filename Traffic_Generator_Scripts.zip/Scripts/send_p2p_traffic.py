import sys
import time
from scapy.all import *
import os

def send_p2p_traffic(target_ip, target_port=6881, count=1000, interval=0.01):
    def create_bittorrent_handshake():
        # BitTorrent handshake message (simplified)
        pstr = b"BitTorrent protocol"  # Protocol string
        reserved = b"\x00\x00\x00\x00\x00\x00\x00\x00"  # Reserved bytes
        info_hash = b"\x00" * 20  # 20-byte info hash (typically a SHA1 hash of the torrent info)
        peer_id = b"-UT0001-" + (b"\x00" * 12)  # Example peer ID

        handshake = pstr + reserved + info_hash + peer_id
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=handshake)

    # Send packets in a loop
    for i in range(count):
        try:
            p2p_packet = create_bittorrent_handshake()
            send(p2p_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_p2p_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_p2p_traffic(target_ip)

import sys
import time
from scapy.all import *
import os

def send_ftp_traffic(target_ip, count=1000, interval=0.01):
    # Craft FTP control packet (Login command)
    ftp_control_payload = "USER anonymous\r\nPASS anonymous\r\n"
    control_packet = IP(dst=target_ip)/TCP(dport=21)/Raw(load=ftp_control_payload)

    # Craft FTP data packet (Example data)
    ftp_data_payload = "DATA" * 100  # Example payload data
    data_packet = IP(dst=target_ip)/TCP(dport=20)/Raw(load=ftp_data_payload)

    # Debug: Print packet details
    control_packet.show()
    data_packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(control_packet, verbose=True)
            send(data_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_ftp_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_ftp_traffic(target_ip)

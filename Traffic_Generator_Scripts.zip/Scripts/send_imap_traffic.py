import sys
import time
from scapy.all import *
import os

def send_imap_traffic(target_ip, target_port=143, count=1000, interval=0.01):
    # Craft IMAP login packet
    imap_login_payload = "a1 LOGIN user@example.com password\r\n"
    login_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=imap_login_payload)

    # Craft IMAP select mailbox packet
    imap_select_payload = "a2 SELECT INBOX\r\n"
    select_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=imap_select_payload)

    # Craft IMAP fetch email packet
    imap_fetch_payload = "a3 FETCH 1 BODY[TEXT]\r\n"
    fetch_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=imap_fetch_payload)

    # Debug: Print packet details
    login_packet.show()
    select_packet.show()
    fetch_packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(login_packet, verbose=True)
            send(select_packet, verbose=True)
            send(fetch_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_imap_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_imap_traffic(target_ip)

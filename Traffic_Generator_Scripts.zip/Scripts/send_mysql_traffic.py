import sys
import time
from scapy.all import *
import os

def send_mysql_traffic(target_ip, target_port=3306, count=1000, interval=0.01):
    # Craft a simple MySQL query packet
    def create_mysql_query_packet():
        # MySQL handshake protocol is complex; here we use a simple query
        query = (
            "SELECT * FROM information_schema.tables;"
        )
        # MySQL packet structure: [length, sequence, command, query]
        # For simplicity, we're using a simplified example without proper MySQL protocol details
        mysql_packet = struct.pack(
            '<IIB',
            len(query) + 1,  # Length of the packet (query length + 1 byte for command)
            0,  # Sequence ID (assuming 0 for simplicity)
            0x03  # Command for query
        ) + query.encode('utf-8') + b'\x00'
        
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=mysql_packet)

    # Send packets in a loop
    for i in range(count):
        try:
            mysql_packet = create_mysql_query_packet()
            send(mysql_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_mysql_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_mysql_traffic(target_ip)

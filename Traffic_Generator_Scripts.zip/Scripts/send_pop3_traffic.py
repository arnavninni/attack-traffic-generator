import sys
import time
from scapy.all import *
import os

def send_pop3_traffic(target_ip, target_port=110, count=1000, interval=0.01):
    # Craft POP3 login packet
    pop3_login_user_payload = "USER user@example.com\r\n"
    pop3_login_pass_payload = "PASS password\r\n"
    login_user_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=pop3_login_user_payload)
    login_pass_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=pop3_login_pass_payload)

    # Craft POP3 list mailboxes packet
    pop3_list_payload = "LIST\r\n"
    list_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=pop3_list_payload)

    # Craft POP3 retrieve email packet
    pop3_retr_payload = "RETR 1\r\n"
    retr_packet = IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=pop3_retr_payload)

    # Debug: Print packet details
    login_user_packet.show()
    login_pass_packet.show()
    list_packet.show()
    retr_packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(login_user_packet, verbose=True)
            send(login_pass_packet, verbose=True)
            send(list_packet, verbose=True)
            send(retr_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_pop3_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_pop3_traffic(target_ip)

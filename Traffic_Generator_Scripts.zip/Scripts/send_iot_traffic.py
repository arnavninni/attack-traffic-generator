import sys
import time
from scapy.all import *

def send_iot_traffic(target_ip, target_port=1883, count=1000, interval=0.01):
    def create_mqtt_connect_packet():
        # MQTT CONNECT Packet
        fixed_header = b"\x10"  # CONNECT packet type
        variable_header = (
            b"\x00\x04MQTT"  # Protocol Name (MQTT)
            b"\x04"  # Protocol Level (MQTT 3.1.1)
            b"\x02"  # Connect Flags (Clean session)
            b"\x00\x3C"  # Keep Alive (60 seconds)
        )
        payload = b"\x00\x00"  # Client Identifier (empty string)
        length = len(variable_header) + len(payload)
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=fixed_header + variable_header + payload)

    def create_mqtt_publish_packet():
        # MQTT PUBLISH Packet
        fixed_header = b"\x30"  # PUBLISH packet type
        variable_header = (
            b"\x00\x01"  # Packet Identifier (1)
        )
        payload = b"Hello from IoT device!"  # Example payload
        length = len(variable_header) + len(payload)
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=fixed_header + variable_header + payload)

    # Send MQTT packets in a loop
    for _ in range(count):
        try:
            connect_packet = create_mqtt_connect_packet()
            publish_packet = create_mqtt_publish_packet()
            send(connect_packet, verbose=True)
            time.sleep(interval)
            send(publish_packet, verbose=True)
            time.sleep(interval)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_iot_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_iot_traffic(target_ip)

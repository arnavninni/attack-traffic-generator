import sys
import time
from scapy.all import *
import os

def send_http_request(target_ip, target_port=80, count=1000, interval=0.001):
    def create_http_request():
        # Craft a simple HTTP GET request
        http_request = (
            "GET / HTTP/1.1\r\n"
            "Host: {}\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).format(target_ip)
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=http_request.encode())

    requests_sent = 0
    # Send HTTP requests in a loop
    while requests_sent < count:
        try:
            http_packet = create_http_request()
            send(http_packet, verbose=True)
            requests_sent += 1
            time.sleep(interval)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_http_request.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_http_request(target_ip)

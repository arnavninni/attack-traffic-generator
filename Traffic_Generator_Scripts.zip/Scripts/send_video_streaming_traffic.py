import sys
import time
from scapy.all import *
import struct
import random

def send_video_streaming_traffic(target_ip, target_port=5004, count=1000, interval=0.01):
    def create_rtp_packet(sequence_number, timestamp, ssrc=87654321):
        rtp_header = struct.pack(
            "!BBHII",
            0x80,     # Version: 2, Padding: 0, Extension: 0, CC: 0
            96,       # Payload type: 96
            sequence_number,
            timestamp,
            ssrc
        )
        video_payload = bytes(f"Video Frame Data {random.randint(0, 1000)}", 'utf-8')
        return IP(dst=target_ip)/UDP(dport=target_port)/Raw(load=rtp_header + video_payload)

    for i in range(count):
        try:
            rtp_packet = create_rtp_packet(sequence_number=1234+i, timestamp=5678+i)
            send(rtp_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_video_streaming_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_video_streaming_traffic(target_ip)

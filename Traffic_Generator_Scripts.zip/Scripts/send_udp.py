import sys
import time
from scapy.all import *
import os

def send_udp(target_ip, target_port, count=1000, interval=0.01):
    # Craft UDP packet
    udp = UDP(dport=target_port)
    packet = IP(dst=target_ip)/udp

    # Debug: Print packet details
    packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python send_udp.py <target_ip> <target_port>")
        sys.exit(1)

    target_ip = sys.argv[1]
    target_port = int(sys.argv[2])
    send_udp(target_ip, target_port)

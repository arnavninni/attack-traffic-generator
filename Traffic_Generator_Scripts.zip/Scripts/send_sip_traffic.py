import sys
import time
from scapy.all import *
import os

def send_sip_traffic(target_ip, target_port=5060, count=1000, interval=0.01):
    # Craft SIP REGISTER packet
    sip_register_payload = (
        "REGISTER sip:example.com SIP/2.0\r\n"
        "Via: SIP/2.0/UDP 192.168.1.100:5060;branch=z9hG4bK-1\r\n"
        "Max-Forwards: 70\r\n"
        "To: <sip:user@example.com>\r\n"
        "From: <sip:user@example.com>;tag=1234\r\n"
        "Call-ID: 1234567890@192.168.1.100\r\n"
        "CSeq: 1 REGISTER\r\n"
        "Contact: <sip:user@192.168.1.100>\r\n"
        "Content-Length: 0\r\n\r\n"
    )
    register_packet = IP(dst=target_ip)/UDP(dport=target_port)/Raw(load=sip_register_payload)

    # Craft SIP INVITE packet
    sip_invite_payload = (
        "INVITE sip:target@example.com SIP/2.0\r\n"
        "Via: SIP/2.0/UDP 192.168.1.100:5060;branch=z9hG4bK-2\r\n"
        "Max-Forwards: 70\r\n"
        "To: <sip:target@example.com>\r\n"
        "From: <sip:user@example.com>;tag=5678\r\n"
        "Call-ID: 1234567890@192.168.1.100\r\n"
        "CSeq: 1 INVITE\r\n"
        "Contact: <sip:user@192.168.1.100>\r\n"
        "Content-Length: 0\r\n\r\n"
    )
    invite_packet = IP(dst=target_ip)/UDP(dport=target_port)/Raw(load=sip_invite_payload)

    # Debug: Print packet details
    register_packet.show()
    invite_packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(register_packet, verbose=True)
            send(invite_packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_sip_traffic.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_sip_traffic(target_ip)

import sys
import time
from scapy.all import *

def send_http_traffic(target_ip, target_port=80, count=1000, interval=0.1):
    def create_http_get_request(path="/", host=None):
        # Craft a simple HTTP GET request
        http_request = (
            "GET {} HTTP/1.1\r\n"
            "Host: {}\r\n"
            "User-Agent: MyTestAgent/1.0\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).format(path, host)
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=http_request.encode())

    for _ in range(count):
        try:
            # Create an HTTP GET request to the root path
            http_packet = create_http_get_request(path="/", host=target_ip)
            send(http_packet, verbose=True)
            time.sleep(interval)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break

def send_https_traffic(target_ip, target_port=443, count=1000, interval=0.1):
    def create_https_request():
        # Simulate HTTPS traffic - no actual encryption
        # A real HTTPS request would be encrypted and not visible in plaintext
        https_request = (
            "GET / HTTP/1.1\r\n"
            "Host: {}\r\n"
            "User-Agent: MyTestAgent/1.0\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).format(target_ip)
        return IP(dst=target_ip)/TCP(dport=target_port)/Raw(load=https_request.encode())

    for _ in range(count):
        try:
            # Create an HTTPS request
            https_packet = create_https_request()
            send(https_packet, verbose=True)
            time.sleep(interval)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python send_web_traffic.py <target_ip> <http/https>")
        sys.exit(1)

    target_ip = sys.argv[1]
    protocol = sys.argv[2].lower()

    if protocol == "http":
        send_http_traffic(target_ip)
    elif protocol == "https":
        send_https_traffic(target_ip)
    else:
        print("Invalid protocol. Use 'http' or 'https'.")
        sys.exit(1)

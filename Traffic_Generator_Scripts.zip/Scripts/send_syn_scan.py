import sys
import time
from scapy.all import *
import os

def send_syn_scan(target_ip, start_port=1, end_port=1024, count=1000, interval=0.001):
    def create_syn_packet(dst_ip, dst_port):
        # Create a TCP SYN packet
        return IP(dst=dst_ip)/TCP(dport=dst_port, flags="S")

    packets_sent = 0
    # Send SYN packets to the range of ports
    for port in range(start_port, end_port + 1):
        try:
            syn_packet = create_syn_packet(target_ip, port)
            send(syn_packet, verbose=True)
            packets_sent += 1
            if packets_sent >= count:
                break
            time.sleep(interval)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_syn_scan.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_syn_scan(target_ip)

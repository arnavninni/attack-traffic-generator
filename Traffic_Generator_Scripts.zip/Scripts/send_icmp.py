import sys
import time
from scapy.all import *
import os

def send_icmp(target_ip, count=1000, interval=0.01):
    # Craft ICMP packet (Echo Request)
    icmp = ICMP()
    packet = IP(dst=target_ip)/icmp

    # Debug: Print packet details
    packet.show()

    # Send packets in a loop
    for _ in range(count):
        try:
            send(packet, verbose=True)
        except PermissionError as e:
            print(f"PermissionError: {e}")
            print("Try running the script as Administrator or with elevated privileges.")
            break
        time.sleep(interval)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python send_icmp.py <target_ip>")
        sys.exit(1)

    target_ip = sys.argv[1]
    send_icmp(target_ip)
